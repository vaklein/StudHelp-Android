<?php

//Define your host here.
$HostName = "127.0.0.1";

//Define your database username here.
$HostUser = "test";

//Define your database password here.
$HostPass = "Bonjour";

//Define your database name here.
$DatabaseName = "test";

?>